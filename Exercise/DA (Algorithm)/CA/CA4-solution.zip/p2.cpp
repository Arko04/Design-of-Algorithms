#include <bits/stdc++.h>

using namespace std;

const int N = 1e4+5;
const int INF = 1e8;

class Edge
{
public:
  Edge(int u,int v,int w) : u(u), v(v), w(w) { }
  int u,v,w,id;
};

int n,m;
int d[N];
int cnt[N];
vector<Edge> e;
vector<int> v[2][N];
int flag[2][N];

void dfs(int x,int id)
{
    flag[id][x] = 1;
    cnt[x]++;
    for (int i = 0; i<v[id][x].size(); i++)
      if (!flag[id][v[id][x][i]])
        dfs(v[id][x][i],id);
}

int main()
{
    cin >> n >> m;
    for (int i = 0; i<m; i++)
    {
      int x,y;
      cin >> x >> y;
      x--; y--;
      e.push_back(Edge(x,y,2));
      e.push_back(Edge(y,x,-1));
      v[0][x].push_back(y);
      v[1][y].push_back(x);
    }
    dfs(0,0);
    dfs(n-1,1);
    for (int i = 1; i<n; i++)
      d[i] = INF;
    for (int i = 0; i<n; i++)
    	for (int j = 0; j<2*m; j++)
    		if (cnt[e[j].u]==2 && cnt[e[j].v]==2)
        		d[e[j].v] = min(d[e[j].v],d[e[j].u]+e[j].w);
    for (int i = 0; i<2*m; i++)
    	if (cnt[e[i].u]==2 && cnt[e[i].v]==2 && d[e[i].v]>d[e[i].u]+e[i].w)
		{
			cout << "No" << endl;
			return 0;
		}
    cout << "Yes" << endl;
    for (int i = 0; i<m; i++)
    	if (cnt[e[i*2].u]!=2 || cnt[e[i*2].v]!=2)
        	cout << 1 << endl;
    	else
        	cout << d[e[i*2].v]-d[e[i*2].u] << endl;
}