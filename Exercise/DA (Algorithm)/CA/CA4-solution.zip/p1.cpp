#include <bits/stdc++.h>

using namespace std;
 
typedef pair<int, int> pii;
typedef long long ll;
typedef pair<ll, ll> pll;
typedef long double ld;
 
struct area {
	int weight, ver;
};
 
int const N = 1e5 + 20;
ll n, m, root[N], sz[N], x, y, ans;
bool vis[N];
area a[N];
vector <int> adj[N];
 
bool cmp( area fi, area se ){
	return fi.weight > se.weight;
}
 
int find(int v){
	if (root[v] == v) return v;
	return root[v] = find(root[v]);
}
 
void merge( int v, int u ){
	v = find(v), u = find(u);
	sz[v] += sz[u];
	root[u] = v;
}
 
int main(){
	ios::sync_with_stdio(false); 
	cin.tie(0);
	cin >> n >> m;
	for (int i = 0 ; i < n ; i ++)
	{
		root[i] = i;
		sz[i] = 1;
	}
	for (int i = 0 ; i < n ; i ++)
	{
		cin >> a[i].weight;
		a[i].ver = i;
	}
	for (int i = 0 ; i < m ; i ++)
	{
		cin >> x >> y; x --, y --;
		adj[x].push_back(y);
		adj[y].push_back(x);
	}
	sort(a, a + n, cmp);
	for (int i = 0 ; i < n ; i ++)
	{
		int v = a[i].ver;
		vis[v] = 1;
		for (auto u : adj[v])
		{
			if ( find(u) != v && vis[u] )
			{
				ans += a[i].weight * sz[find(u)] * sz[v];
				merge( v, u );
			}
		}
	}
	cout << ans << endl;
}