#include <bits/stdc++.h>

using namespace std;

typedef long long ll;
typedef pair<int,ll> pii;
typedef pair<int, pair<ll,int> > piii;

#define F first
#define S second

const int N = 605;
const ll INF = 1e12;

class Adjacenty
{
public:
    int v;
    ll w;
    int edge_id;
    Adjacenty(int _v, ll _w, int _id): v(_v), w(_w), edge_id(_id) { }
};

int n,m,k;
vector<piii> adj[N];
vector<pii> q[N];
// floyd
ll dist[N][N];
// dijkstra
int f[N];
set<pii> st;
ll d[N];

int res[N*N];
int ans;

int main()
{
    cin >> n >> m;
    for (int i = 0; i<n; i++)
        for (int j = 0; j<n; j++)
            dist[i][j] = INF;
    for (int i = 0; i<n; i++)
        dist[i][i] = 0;
    for (int i = 0; i<m; i++)
    {
        int x,y,w;
        cin >> x >> y >> w;
        x--; y--;
        adj[x].push_back({y,{w,i}});
        adj[y].push_back({x,{w,i}});
        dist[x][y] = dist[y][x] = w;
    }
    cin >> k;
    for (int i = 0; i<k; i++)
    {
        int a,b;
        ll l;
        cin >> a >> b >> l;
        a--; b--;
        q[a].push_back({b,l});
        q[b].push_back({a,l});
    }
    for (int k = 0; k<n; k++)
        for (int i = 0; i<n; i++)
            for (int j = 0; j<n; j++)
                if (dist[i][k] + dist[k][j] < dist[i][j])  
                    dist[i][j] = dist[i][k] + dist[k][j];
    for (int v = 0; v<n; v++)
    {
        memset(f, 0, sizeof(f));
        for (int i = 0; i<n; i++)
            d[i] = INF;
        for (pii p: q[v])
        {
            int u = p.first;
            ll l = p.second;
            d[u] = -l;
        }
        for (int i = 0; i<n; i++)
        {
            int a = -1;
            ll dis = INF;
            for (int j = 0; j<n; j++)
                if (!f[j] && d[j]<dis)
                {
                    dis = d[j];
                    a = j;
                }
            if (a==-1)
                break;
            f[a] = 1;
            for (piii b: adj[a])
                if (!f[b.F] && dis+(b.S.F)<d[b.F])
                    d[b.F] = dis+(b.S.F);
        }
        for (int a = 0; a<n; a++)
            for (piii p: adj[a])
            {
                int b = p.F;
                ll w = p.S.F;
                int id = p.S.S;
                if (d[b]<=-w-dist[v][a])
                {
                    res[id] = 1;
                }
            }
    }
    for (int i = 0; i<m; i++)
        if (res[i])
            ans++;
    cout << ans << endl;
}