#include <iostream>
using namespace std;

const int MAXN = 100 * 1000 + 10;

long long dp[2][MAXN];
long long a[2][MAXN];

int main () {
	ios::sync_with_stdio(false);

	int n; cin >> n;
	for (int i = 0; i < 2; i++)
		for (int j = 0; j < n; j++)
			cin >> a[i][j];

	dp[0][0] = a[0][0];
	dp[1][0] = a[0][0] + a[1][0];

	for (int i = 1; i < n; i++) {
		long long tmp0 = dp[0][i - 1] + a[0][i];
		long long tmp1 = dp[1][i - 1] + a[1][i];

		dp[0][i] = max(tmp0, tmp1 + a[0][i]);
		dp[1][i] = max(tmp1, tmp0 + a[1][i]);
	}

	cout << dp[1][n - 1] << endl;
	return 0;
}

