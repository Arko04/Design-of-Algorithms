#include <iostream>
using namespace std;

long long find_n(long long x) {
	long long res = 0;
	while (x > 0) {
		x = x / 5;
		res += x;
	}
	return res;
}

int main () {
	long long m;
	cin >> m;

	long long l = -1, r = 5 * m + 1;
	while (r - l > 1) {
		long long mid = (l + r) / 2, cur = find_n(mid);
		if (cur < m) l = mid;
		else r = mid;
	}
	cout << (find_n(r) == m ? r : -1) << endl;

	return 0;
}

