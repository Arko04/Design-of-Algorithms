#include <bits/stdc++.h>
#define ll long long
#define X first
#define Y second
#define pb push_back
using namespace std;
const int N = 200200;
const int M = 100100;
map<int,int> mp,mpr;
int n,m,k;
int d,s,e;
int m2;
vector<pair<pair<int,int>,int> > adj[N];
ll dist[N];
ll djk(int p,ll val)
{
	for(int i=0;i<n;i++)
		dist[i]=1e15;
	dist[s]=0;
	set<pair<ll,int>> pq;
	pq.insert({0,s});
	while(!pq.empty())
	{
		pair<ll,int> x=*pq.begin();
		int v=x.Y;
		pq.erase(pq.begin());
		for(int i=0;i<adj[v].size();i++)
		{
			int u=adj[v][i].X.X,w=adj[v][i].X.Y,lb=adj[v][i].Y;
			if(lb>=0)
				if(lb<p)
					w=1;
				else if(lb==p)
					w=val;
				else
					w=1e9;
			if(x.X+w<dist[u])
			{
				pq.erase({dist[u],u});
				dist[u]=x.X+w;
				pq.insert({dist[u],u});
			}
		}
	}
	return dist[e];
}
void print(int p, ll val)
{
	for(int i=0;i<n;i++)
		for(int j=0;j<adj[i].size();j++)
		{
			int lb=adj[i][j].Y;
			if(lb>=0)
				if(lb<p)
					adj[i][j].X.Y=1;
				else if(lb==p)
					adj[i][j].X.Y=val;
				else
					adj[i][j].X.Y=1e9;
		}
	cout<<"Yes"<<endl;
	for(int i=0;i<n;i++)
		for(int j=0;j<adj[i].size();j++)
		{
			int v=adj[i][j].X.X,w=adj[i][j].X.Y; 
			if(i<v)
				cout<<mpr[i]<<" "<<mpr[v]<<" "<<w<<endl;
		}
}
int main()
{
	int tmp;
	cin>>tmp>>m>>k;
	for(int i=0;i<m;i++)
	{
		int v,u,w;
		cin>>v>>u>>w;
		if(!mp.count(v))
		{
			mpr[n]=v;
			mp[v]=n++;
		}
		if(!mp.count(u))
		{
			mpr[n]=u;
			mp[u]=n++;
		}
		v=mp[v];
		u=mp[u];
		int lb=-1;
		if(!w)
			lb = m2++;
		adj[v].pb({{u,w},lb});
		adj[u].pb({{v,w},lb});
	}
	m2++;
	if(!mp.count(1))
	{
		mpr[n]=1;
		mp[1]=n++;
	}
	if(!mp.count(tmp))
	{
		mpr[n]=tmp;
		mp[tmp]=n++;
	}
	s=mp[1];
	e=mp[tmp];
	cin>>d;
	ll x=djk(m2,1);
	ll y=djk(-1,1);
	if(x>d || d>y)
	{
		cout<<"No"<<endl;
		return 0;
	}
	int lo=-1,hi=m2+1,mid;
	while(lo<hi)
	{
		mid=(lo+hi+2)/2-1;
		if(djk(mid,1)<=d)
			hi=mid;
		else
			lo=mid+1;
	}
	if(hi==-1)
	{
		print(-1, 0);
		return 0;
	}
	int ans=hi;
	lo=1;
	hi=1e9+1;
	while(lo<hi)
	{
		mid=(lo+hi)/2;
		if(djk(ans,mid)<=d)
			lo = mid + 1;
		else
			hi = mid;
	}
	print(ans,lo-1);
	return 0;
}