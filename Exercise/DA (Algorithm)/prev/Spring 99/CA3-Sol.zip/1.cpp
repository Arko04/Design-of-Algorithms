#include <bits/stdc++.h>
#define ll long long
#define X first
#define Y second
#define pb push_back
using namespace std;
const int oo = 1<<29, N = 1000;
int a[N][N],f[N];
bool b[N][N];
vector<pair<int,pair<int,int> > > v;
int p(int x)
{
	return f[x]==x?x:f[x]=p(f[x]);
}
bool un(int x,int y)
{
	return p(x)==p(y)?false:(f[p(x)]=p(y),true);
}
int main()
{
	int n,c;
	ll ans=0;
	cin>>n>>c;
	for(int i=0;i<n;i++)
		for(int j=0;j<n;j++)
		{
			cin>>a[i][j];
			ans+=a[i][j];
			v.pb({a[i][j],{i,j}});
		}
	for(int i=0;i<n;i++)
		f[i]=i;
	sort(v.begin(),v.end());
	int sv=0;
	for(int i=0;i<v.size();i++)
	{
		if(i && v[i].X!=v[i-1].X)
		{
			for(int j=sv;j<i;j++)
				if(un(v[j].Y.X,v[j].Y.Y))
					ans-=v[j].X;
			sv=i;
		}
		if(p(v[i].Y.X)==p(v[i].Y.Y))
			b[v[i].Y.X][v[i].Y.Y]=1;
	}
	for(int i=sv;i<v.size();i++)
		if(un(v[i].Y.X,v[i].Y.Y))
			ans-=v[i].X;
	cout<<ans/c<<endl;
	for(int i=0;i<n;i++,cout<<endl)
		for(int j=0;j<n;j++)
			cout<<b[i][j]<<" ";
	return 0;
}