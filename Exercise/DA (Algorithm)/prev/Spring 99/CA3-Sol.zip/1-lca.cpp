#include <bits/stdc++.h>
#define ll long long
#define X first
#define Y second
#define pb push_back
using namespace std;
const int oo = 1<<29, N = 1000, LG = 20;
int a[N][N],f[N],par[N][LG],mx[N][LG],d[N];
bool b[N][N];
vector<pair<int,int> > adj[N];
vector<pair<int,pair<int,int> > > v;
int p(int x)
{
	return f[x]==x?x:f[x]=p(f[x]);
}
bool un(int x,int y)
{
	return p(x)==p(y)?false:(f[p(x)]=p(y),true);
}
void dfs(int v)
{
	int u;
	for(int i=0;i<adj[v].size();i++)
		if((u=adj[v][i].X)!=par[v][0])
		{
			d[u]=d[v]+1;
			par[u][0]=v;
			mx[u][0]=adj[v][i].Y;
			for(int j=1;j<LG;j++)
			{
				par[u][j]=par[par[u][j-1]][j-1];
				mx[u][j]=max(mx[u][j-1],mx[par[u][j-1]][j-1]);
			}
			dfs(u);
		}
}
int mxp(int x,int y)
{
	int ans=0;
	if(d[x]<d[y])
		swap(x,y);
	for(int i=19;i>=0;i--)
		if(d[par[x][i]]>=d[y])
		{
			ans=max(ans,mx[x][i]);
			x=par[x][i];
		}
	if(x==y)
		return ans;
	for(int i=19;i>=0;i--)
		if(par[x][i]!=par[y][i])
		{
			ans=max(ans,max(mx[x][0],mx[y][0]));
			x=par[x][i];
			y=par[y][i];
		}
	ans=max(ans,max(mx[x][0],mx[y][0]));
	return ans;
}
int main()
{
	int n,c;
	ll ans=0;
	cin>>n>>c;
	for(int i=0;i<n;i++)
		for(int j=0;j<n;j++)
		{
			cin>>a[i][j];
			ans+=a[i][j];
			v.pb({a[i][j],{i,j}});
		}
	for(int i=0;i<n;i++)
		f[i]=i;
	sort(v.begin(),v.end());
	for(int i=0;i<v.size();i++)
		if(un(v[i].Y.X,v[i].Y.Y))
		{
			ans-=v[i].X;
			adj[v[i].Y.X].pb({v[i].Y.Y,v[i].X});
			adj[v[i].Y.Y].pb({v[i].Y.X,v[i].X});
		}
		else
			b[v[i].Y.X][v[i].Y.Y]=1;
	cout<<ans/c<<endl;
	ll err=ans-(ans/c)*c;
	dfs(0);
	for(int i=0;i<n;i++)
		for(int j=0;j<n;j++)
			if(b[i][j])
				b[i][j]=(a[i][j]-mxp(i,j)>err);
	for(int i=0;i<n;i++,cout<<endl)
		for(int j=0;j<n;j++)
			cout<<b[i][j]<<" ";
	return 0;
}