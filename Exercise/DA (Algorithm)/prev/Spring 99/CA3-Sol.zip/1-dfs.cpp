#include <bits/stdc++.h>
#define ll long long
#define X first
#define Y second
#define pb push_back
using namespace std;
const int oo = 1<<29, N = 1000;
int a[N][N],mx[N][N],f[N];
bool b[N][N];
vector<pair<int,int> > adj[N];
vector<pair<int,pair<int,int> > > v;
int p(int x)
{
	return f[x]==x?x:f[x]=p(f[x]);
}
bool un(int x,int y)
{
	return p(x)==p(y)?false:(f[p(x)]=p(y),true);
}
void dfs(int st,int v,int p=-1)
{
	int u;
	for(int i=0;i<adj[v].size();i++)
		if((u=adj[v][i].X)!=p)
		{
			mx[st][u]=max(mx[st][v],adj[v][i].Y);
			dfs(st,u,v);
		}
}
int main()
{
	int n,c;
	ll ans=0;
	cin>>n>>c;
	for(int i=0;i<n;i++)
		for(int j=0;j<n;j++)
		{
			cin>>a[i][j];
			ans+=a[i][j];
			v.pb({a[i][j],{i,j}});
		}
	for(int i=0;i<n;i++)
		f[i]=i;
	sort(v.begin(),v.end());
	for(int i=0;i<v.size();i++)
		if(un(v[i].Y.X,v[i].Y.Y))
		{
			ans-=v[i].X;
			adj[v[i].Y.X].pb({v[i].Y.Y,v[i].X});
			adj[v[i].Y.Y].pb({v[i].Y.X,v[i].X});
		}
		else
			b[v[i].Y.X][v[i].Y.Y]=1;
	cout<<ans/c<<endl;
	ll err=ans-(ans/c)*c;
	for(int i=0;i<n;i++)
		dfs(i,i);
	for(int i=0;i<n;i++)
		for(int j=0;j<n;j++)
			if(b[i][j])
				b[i][j]=(a[i][j]-mx[i][j]>err);
	for(int i=0;i<n;i++,cout<<endl)
		for(int j=0;j<n;j++)
			cout<<b[i][j]<<" ";
	return 0;
}