#include<bits/stdc++.h>
#define ll long long
#define X first
#define Y second
#define pb push_back
using namespace std;
const int N=1010;
int n,m;
ll dis[N];
vector<pair<int,int> > adj[N];
int main()
{
	cin>>n>>m;
	n++;
	for(int i=1;i<n;i++)
		adj[i].pb({i-1,-i/(n-1)});
	for(int i=0;i<m;i++)
	{
		int a,b,c;
		char ch;
		cin>>a>>ch>>b>>ch>>c;
		if(ch=='>')
			adj[b].pb({a-1,-c-1});
		else
			adj[a-1].pb({b,c-1});
	}
	for(int i=0;i<n;i++)
		for(int j=0;j<n;j++)
			for(int k=0;k<adj[j].size();k++)
				dis[adj[j][k].X]=min(dis[adj[j][k].X],dis[j]+adj[j][k].Y);
	for(int i=0;i<n;i++)
		for(int j=0;j<adj[i].size();j++)
			if(dis[adj[i][j].X]>dis[i]+adj[i][j].Y)
				return cout<<"No"<<endl,0;
	cout<<"Yes"<<endl;
	for(int i=1;i<n;i++)
		cout<<dis[i]-dis[i-1]<<" ";
	cout<<endl;
}