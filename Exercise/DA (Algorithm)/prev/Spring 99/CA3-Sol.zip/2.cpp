#include <bits/stdc++.h>
#define ll long long
#define X first
#define Y second
#define pb push_back
using namespace std;
int const N=550;
ll dis[N][N],dp1[N],dp2[N];
int main()
{
    int n,m;
    cin>>n>>m;
    for(int i=0;i<n;i++)
        for(int j=i+1;j<n;j++)
            dis[i][j]=dis[j][i]=1e17;
    for(int i=0;i<m;i++)
    {
        int v,u,w;
        cin>>v>>u>>w;
        v--;
        u--;
        dis[v][u]=min(dis[v][u],(ll)w);
        dis[u][v]=min(dis[u][v],(ll)w);
    }
    for(int i=0;i<n;i++)
        for(int j=0;j<n;j++)
            for(int l=0;l<n;l++)
                dis[j][l]=min(dis[j][l],dis[j][i]+dis[i][l]);
    int q,k;
    cin>>q>>k;
    while(q--)
    {
        int v,u;
        cin>>v>>u;
        v--;
        u--;
        ll ans=max(dp1[v]+dis[v][u],dp2[u])+k;
        dp1[v]=dp2[v]=ans+dis[v][u];
        dp1[u]=max(dp1[u],ans);
        cout<<ans<<endl;
    }
    return 0;
}