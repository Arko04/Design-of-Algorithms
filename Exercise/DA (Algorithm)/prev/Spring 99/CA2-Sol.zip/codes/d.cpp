#include <iostream>
#include <cmath>

using namespace std;

const int N = 256;
const int MAXN = 256+5;
const long long INF = 1e15;

long long a[MAXN];
long long prel[MAXN][MAXN],prer[MAXN][MAXN];
long long dp[MAXN][MAXN];

int main()
{
    int n,m;
    cin >> n >> m;
    for (int i = 0; i<n; i++)
    {
        int x,y;
        cin >> x >> y;
        a[x] += y;
    }
    for (int i = 0; i<N; i++)
        prel[i][i] = prer[i][i] = 0;
    for (int i = 0; i<N; i++)
        for (int j = i+1; j<N; j++)
            prel[i][j] = prel[i][j-1]+((j-i)*(j-i)*a[j]);
    for (int j = 0; j<N; j++)
        for (int i = j-1; i>=0; i--)
            prer[i][j] = prer[i+1][j]+((j-i)*(j-i)*a[i]);
            
    dp[N][0] = 0;
    for (int i = 1; i<=m; i++)
        dp[N][i] = INF;
    for (int i = N-1; i>=0; i--)
        for (int j = 0; j<=m; j++)
        {
            if (j==0)
            {
                dp[i][j] = INF;
                continue;
            }
            dp[i][j] = dp[i+1][j-1];
            long long r = 0;
            for (int k = i+1; k<N; k++)
                r += (k-i)*(k-i)*a[k];
            dp[i][j] = min(dp[i][j],r);
            for (int k = i+1; k<N; k++)
                dp[i][j] = min(dp[i][j],dp[k][j-1]+prel[i][i+(k-i)/2]+prer[i+(k-i)/2+1][k]);
        }
    long long ans = INF;
    for (int i = 0; i<N; i++)
    {
        ans = min(ans,dp[i][m]+prer[0][i]);
    }
    cout << ans << endl;
}