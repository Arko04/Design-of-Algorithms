#include <bits/stdc++.h>
using namespace std;

const int N = 1e5+10;
const int INF = 1e11;

long long n, a[N], dp[N][2];
vector<int> adj[N];

void dfs(int v) {
    long long tot = 0, parity = 0, alt = INF;
    for (int u : adj[v]) {
        dfs(u);
        if (dp[u][0] < dp[u][1]) {
            tot += dp[u][1];
            alt = min(alt, dp[u][1] - dp[u][0]);
            parity ^= 1;
        } else {
            tot += dp[u][0];
            alt = min(alt, dp[u][0] - dp[u][1]);
        }
    }
    if (parity) {
        dp[v][0] = tot-alt;
        dp[v][1] = max(tot, tot-alt+a[v]);
    } else {
        dp[v][0] = tot;
        dp[v][1] = tot + a[v];
    }
}


int main() {
    cin >> n;
    for (int i = 0; i < n; i++) {
        int p;
        cin >> p >> a[i];
        p --;
        if (i > 0) 
            adj[p].push_back(i);
    }
    dfs(0);
    cout << max(dp[0][0], dp[0][1]) << '\n';
}