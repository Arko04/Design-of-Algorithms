#include <bits/stdc++.h>

using namespace std;

const int N = 1e4+10;
const int Q = 101;

int n,len;
int a[N];
int q;
int b[N],org[N];
int dp[N][Q];

int is_different(int i, int j)
{
    if (a[i] != a[j])
        return 1;
    else
        return 0;
}

int get_similarity(int ind1, int ind2)
{
    int res = 0;
    for (int i = 0; i<len; i++)
        res += is_different(ind1+i, ind2+i);
    return res;
}

void add_result(int i,int val)
{
    int ind = lower_bound(b, b+q, val)-b;
    dp[i][ind]++;
}

int main()
{
    cin >> n >> len;
    for (int i = 0; i<n; i++)
        cin >> a[i];
    cin >> q;
    for (int i = 0; i<q; i++)
        cin >> b[i];
    memcpy(org, b, sizeof(b));
    sort(b, b+q);
    for (int diff = 1; diff<=n-len; diff++)
    {
        int ind1 = 0, ind2 = diff;
        int current_similarity = get_similarity(ind1, ind2);
        for (int i = len; i+diff<n; i++)
        {
            add_result(ind1, current_similarity);
            add_result(ind2, current_similarity);
            current_similarity -= is_different(ind1, ind2);
            current_similarity += is_different(ind1+len, ind2+len);
            ind1++;
            ind2++;
        }
        add_result(ind1, current_similarity);
        add_result(ind2, current_similarity);
    }
    for (int i = 0; i<n-len+1; i++)
        for (int j = 1; j<q; j++)
            dp[i][j] += dp[i][j-1];
    for (int i = 0; i<q; i++)
    {
        int ind = lower_bound(b, b+q, org[i])-b;
        for (int j = 0; j<n-len+1; j++)
            cout << dp[j][ind] << ' ';
        cout << endl;
    }
}