#include <bits/stdc++.h>

using namespace std;

int const N = 2020;

int n;
bool vis[N], col[N];
vector<int> adj[N];

bool intersect(int a, int b, int c, int d) {
    if (b<a)
        swap(a,b);
    if (d<c)
        swap(c,d);
    return ((c>=a+1 && c<b) && 
                ((d>=b+1 && d<n+1) || (d>=1 && d<a))) ||
            ((d>=a+1 && d<b) && ((c>=b+1 && c<n+1) || (c>=1 && c<a)));
}

void dfs(int v) {
    vis[v] = 1;
    for (int u : adj[v]) {
        if (vis[u]) {
            if (col[u] == col[v]) {
                cout << "Impossible\n";
                exit(0);
            }
        } else {
            col[u] = !col[v];
            dfs(u);
        }
    }
}

int main() {
    ios::sync_with_stdio(false);
    cin.tie(0);

    int m, a[N], b[N];
    cin >> n >> m;
    for (int i = 0; i < m; i++) 
        cin >> a[i] >> b[i];

    for (int i = 0; i<m; i++)
        for (int j = i+1; j<m; j++)
            if (intersect(a[i], b[i], a[j], b[j]))
            {
                adj[i].push_back(j);
                adj[j].push_back(i);
            }
    for (int i = 0; i < m; i++) {
        if (!vis[i])
            dfs(i);
    }
    for (int v = 0; v < m; v++) {
        cout << (col[v] ? 'I' : 'O');
    }
    cout << '\n';
}